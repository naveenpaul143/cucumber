package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features ="src/test/resources/Features/Login.feature",
glue = "StepDefinitions", //we can give package name only
monochrome = true,
//tags = "@valid",
//tags = "@invalid",
plugin= {"pretty","html:HTML_Reports/html_report1.html",
		"json:JSON_Reports/json_report1.json",
		"junit:XML_Reports/xml_report1.xml"
		}  //pretty-human readable format

		)
public class TestRunner {
//This is only for the configuration purpose
}
