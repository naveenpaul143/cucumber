package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features ="src/test/resources/Features/MyWebsite.feature",
glue = "StepDefinitions", //we can give package name only
monochrome = true,
plugin= {"pretty","html:HTML_Reports/html_report2.html",
		"json:JSON_Reports/json_report2.json",
		"junit:XML_Reports/xml_report2.xml"
		}  //pretty-human readable format

		)
public class MyWebsiteTestRunner {

}
