package StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchSteps {
	@Given("user is opens browser")
	public void user_is_opens_browser() {
		System.out.println("user is opens browser");
	    
	}

	@And("user is on search page")
	public void user_is_on_search_page() {
		System.out.println("user is on search page");
	   
	}

	@When("user enters a valid search as {string}")
	public void user_enters_a_valid_search_as_parametrization(String validInput) {
	    System.out.println("valid input:"+validInput);
	}

	@When("user clicks on a search button")
	public void user_clicks_on_a_search_button() {
		System.out.println("user clicks on a search button");
	   
	}

	@Then("user should see the relevant search details")
	public void user_should_see_the_relevant_search_details() {
		System.out.println("user should see the relevant search details");
	    
	}

	@Then("validate the search details")
	public void validate_the_search_details() {
		System.out.println("validate the search details");
	    
	}
	@When("user enters a invalid search")
	public void user_enters_a_invalid_search() {
	    System.out.println("user enters a invalid search");
	}

	@Then("user should see the error message")
	public void user_should_see_the_error_message() {
	   System.out.println("user should see the error message");
	}
	@When("user enters a invalid search as {string}")
	public void user_enters_a_invalid_search_as(String invalid) {
	    System.out.println("Invalid input:"+invalid);
	}
	

}
