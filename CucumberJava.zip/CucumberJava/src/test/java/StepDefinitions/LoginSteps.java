package StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	@Given("user is on login page")
	public void user_is_on_login_page() {
	    System.out.println("user is on login page");
	}

	@When("user enters {string} and {string}")
	public void user_enters_and(String user, String pwd) {
	    System.out.println(user+"==="+pwd);
	}


	@When("clicks on login button")
	public void clicks_on_login_button() {
	    System.out.println("user clicks on login button");
	}

	@Then("user is navigated to home page")
	public void user_is_navigated_to_home_page(io.cucumber.datatable.DataTable dataTable) {
	   System.out.println("user navigated to home page");
	}

}
