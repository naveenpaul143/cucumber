package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearchSteps {

	@Given("user opens browser")
	public void user_opens_browser() {
	    System.out.println("user open browser");
	}

	@When("user enters valid search")
	public void user_enters_valid_search() {
		System.out.println("user enters valid search");
	    
	}

	@Then("user shoud see relevant search results")
	public void user_shoud_see_relevant_search_results() {
	   System.out.println("user should see relevant results");
	}

}
