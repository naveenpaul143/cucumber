package StepDefinitions;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MyWebsiteSteps {
	WebDriver d;
	//These symbols are used in regular expressions to define patterns for matching text
	@Given("^Open the Chrome and start the application$") //In Cucumber, the caret (^) and dollar sign ($) symbols are used to represent the start and end of a string, respectively.
	public void open_the_chrome_and_start_the_application() {
	   WebDriverManager.chromedriver().setup();
	   ChromeOptions opt=new ChromeOptions();
	   opt.addArguments("--start-maximized");
	   d=new ChromeDriver(opt);
	   d.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	   d.get("https://naveenpaul143.github.io/Testing/home.html");
//	   d.manage().window().maximize();
	   
	}

//	@When("^I enter valid (.*) and valid (.*)$")
	@When("I enter valid {string} and valid {string}")
	public void i_enter_valid_username_and_valid_password(String user,String pwd) {
	    
		d.findElement(By.id("username1")).sendKeys(user);
		d.findElement(By.id("password1")).sendKeys(pwd);
	}

	@Then("^user should be able to login successfully$")
	public void user_should_be_able_to_login_successfully() throws InterruptedException {
	   d.findElement(By.cssSelector("input[type=submit]")).click();
	   Thread.sleep(3000);
	   d.close();
	}
}
