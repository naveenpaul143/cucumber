package StepDefinitions;

import java.util.List;
import java.util.Map;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DatatableSteps {
	@Given("user launch login page url")
	public void user_launch_login_page_url() {
	   System.out.println("user launch login page url");
	}

	@When("user is on login page and verify login page")
	public void user_is_on_login_page_and_verify_login_page() {
	  System.out.println("user verify login page");
	}

	@When("user enters Username and password in login page")
	public void user_enters_username_and_password_in_login_page(DataTable dataTable) {
	    
		//List<List<String>> data=dataTable.asLists(String.class);   //For single data we can use this using asList()
		 
		List<Map<String,String>> listdata=dataTable.asMaps(String.class,String.class);  //using asMaps()
		
//		System.out.println(data.get(0).get(0));
//		System.out.println("================");
//		System.out.println(data.get(0).get(1));
		 
		 //To get the single data username and password
//		System.out.println(listdata.get(0).get("username"));
//	  	System.out.println(listdata.get(0).get("password"));
		 
		 //Iteration
		 for(Map<String,String> mapdata:listdata) {
		 System.out.println(mapdata.get("username"));
         System.out.println(mapdata.get("password"));
		 }
		
	}

	@Then("User Navigated to Main page")
	public void user_navigated_to_main_page() {
	    
	}
}
